// locks.h - Thread synchronization primitives. Generic implementation.

/* Copyright (C) 2002  Free Software Foundation

   This file is part of libgcj.

This software is copyrighted work licensed under the terms of the
Libgcj License.  Please consult the file "LIBGCJ_LICENSE" for
details.  */

#error Thread synchronization primitives not implemented for this platform.
