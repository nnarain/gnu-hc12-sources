// Given a function pointer, return the code address.

#define UNWRAP_FUNCTION_DESCRIPTOR(X)  (X)
