#include <string>
#include <iostream>

int
main (int argc, char *argv[])
{
    std::string myStr = "Hello, World!";
    std::cout << myStr << std::endl;
    return 0;
}
