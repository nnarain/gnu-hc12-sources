char k [500];
