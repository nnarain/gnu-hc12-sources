#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char zoo [10];

int main ()
{
int i = strlen ("eight") + strlen ("one");
zoo[i] = 'a';
return 0;
}
