#define INTEGER_ONLY
#include "vsscanf.c"
