#define INTEGER_ONLY
#include "vsnprintf.c"
