#ifndef _SYS_SYSCALL_H
#define _SYS_SYSCALL_H
int __send_to_ppe(unsigned int signalcode, unsigned int opcode, void *data);
#endif
