/* empty stub so there's at least one file to put in objectlist.awk.in */
