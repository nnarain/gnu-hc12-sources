#include <time.h>

/* Global timezone variables.  */

/* Default timezone to GMT */
char *_tzname[2] = {"GMT", "GMT"};
int _daylight = 0;
long _timezone = 0;


